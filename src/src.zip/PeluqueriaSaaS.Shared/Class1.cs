﻿namespace PeluqueriaSaaS.Shared;

public class Class1
{

}
