/*
 * Archivo: src/PeluqueriaSaaS.Application/DTOs/ServicioDtos.cs
 * Propósito: DTOs para servicios - CORREGIDO PARA COMPILAR
 * Fecha: Julio 2025
 * CORRECCIONES: TipoServicioId cambiado de Guid a int
 */

using System.ComponentModel.DataAnnotations;
using PeluqueriaSaaS.Domain.Entities;
using PeluqueriaSaaS.Domain.ValueObjects;

namespace PeluqueriaSaaS.Application.DTOs
{
    /// <summary>
    /// DTO para mostrar información completa de un servicio
    /// </summary>
    public class ServicioDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string? Descripcion { get; set; }
        public decimal Precio { get; set; }
        public string MonedaCodigo { get; set; } = string.Empty;
        public int DuracionMinutos { get; set; }
        public int TipoServicioId { get; set; } // ✅ CORREGIDO: Guid → int
        public string TipoServicioNombre { get; set; } = string.Empty;
        public bool EsActivo { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime? FechaActualizacion { get; set; }
        public string TenantId { get; set; } = string.Empty;

        // Propiedades calculadas para la vista
        public string PrecioFormateado => $"${Precio:N2} {MonedaCodigo}";
        public string DuracionFormateada
        {
            get
            {
                if (DuracionMinutos < 60)
                    return $"{DuracionMinutos} min";
                else if (DuracionMinutos == 60)
                    return "1 hora";
                else if (DuracionMinutos % 60 == 0)
                    return $"{DuracionMinutos / 60} horas";
                else
                {
                    int horas = DuracionMinutos / 60;
                    int minutos = DuracionMinutos % 60;
                    return $"{horas}h {minutos}min";
                }
            }
        }
        public string EstadoTexto => EsActivo ? "Activo" : "Inactivo";
        public string EstadoCssClass => EsActivo ? "badge-success" : "badge-danger";

        /// <summary>
        /// Convierte una entidad Servicio a DTO
        /// </summary>
        public static ServicioDto FromEntity(Servicio servicio)
        {
            return new ServicioDto
            {
                Id = servicio.Id,
                Nombre = servicio.Nombre,
                Descripcion = servicio.Descripcion,
                Precio = servicio.Precio.Valor,
                MonedaCodigo = servicio.Precio.Moneda,
                DuracionMinutos = servicio.DuracionMinutos,
                TipoServicioId = servicio.TipoServicioId, // ✅ CORREGIDO: ahora es int
                TipoServicioNombre = servicio.TipoServicio?.Nombre ?? "Sin categoría",
                EsActivo = servicio.EsActivo,
                FechaCreacion = servicio.FechaCreacion,
                FechaActualizacion = servicio.FechaActualizacion,
                TenantId = servicio.TenantId
            };
        }
    }

    /// <summary>
    /// DTO para crear un nuevo servicio
    /// </summary>
    public class ServicioCreateDto
    {
        [Required(ErrorMessage = "El nombre del servicio es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder los 100 caracteres")]
        [Display(Name = "Nombre del Servicio")]
        public string Nombre { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "La descripción no puede exceder los 500 caracteres")]
        [Display(Name = "Descripción")]
        public string? Descripcion { get; set; }

        [Required(ErrorMessage = "El precio es requerido")]
        [Range(0.01, 999999.99, ErrorMessage = "El precio debe estar entre 0.01 y 999999.99")]
        [Display(Name = "Precio")]
        [DataType(DataType.Currency)]
        public decimal Precio { get; set; }

        [Required(ErrorMessage = "La moneda es requerida")]
        [Display(Name = "Moneda")]
        public string MonedaCodigo { get; set; } = "CLP"; // Valor por defecto para Chile

        [Required(ErrorMessage = "La duración es requerida")]
        [Range(1, 1440, ErrorMessage = "La duración debe estar entre 1 y 1440 minutos")]
        [Display(Name = "Duración (minutos)")]
        public int DuracionMinutos { get; set; }

        [Required(ErrorMessage = "El tipo de servicio es requerido")]
        [Display(Name = "Tipo de Servicio")]
        public int TipoServicioId { get; set; } // ✅ CORREGIDO: Guid → int

        /// <summary>
        /// Convierte el DTO a una entidad Servicio
        /// </summary>
        public Servicio ToEntity(string tenantId) // ✅ CORREGIDO: string tenantId (no Guid)
        {
            var dinero = new Dinero(Precio, MonedaCodigo);
            return new Servicio(Nombre, dinero, DuracionMinutos, TipoServicioId, Descripcion);
        }
    }

    /// <summary>
    /// DTO para actualizar un servicio existente
    /// </summary>
    public class ServicioUpdateDto
    {
        [Required]
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del servicio es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder los 100 caracteres")]
        [Display(Name = "Nombre del Servicio")]
        public string Nombre { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "La descripción no puede exceder los 500 caracteres")]
        [Display(Name = "Descripción")]
        public string? Descripcion { get; set; }

        [Required(ErrorMessage = "El precio es requerido")]
        [Range(0.01, 999999.99, ErrorMessage = "El precio debe estar entre 0.01 y 999999.99")]
        [Display(Name = "Precio")]
        [DataType(DataType.Currency)]
        public decimal Precio { get; set; }

        [Required(ErrorMessage = "La moneda es requerida")]
        [Display(Name = "Moneda")]
        public string MonedaCodigo { get; set; } = "CLP";

        [Required(ErrorMessage = "La duración es requerida")]
        [Range(1, 1440, ErrorMessage = "La duración debe estar entre 1 y 1440 minutos")]
        [Display(Name = "Duración (minutos)")]
        public int DuracionMinutos { get; set; }

        [Required(ErrorMessage = "El tipo de servicio es requerido")]
        [Display(Name = "Tipo de Servicio")]
        public int TipoServicioId { get; set; } // ✅ CORREGIDO: Guid → int

        [Display(Name = "Estado")]
        public bool EsActivo { get; set; } = true;

        /// <summary>
        /// Crea un ValueObject Dinero a partir de las propiedades del DTO
        /// </summary>
        public Dinero GetDinero()
        {
            return new Dinero(Precio, MonedaCodigo);
        }

        /// <summary>
        /// Llena el DTO desde una entidad Servicio
        /// </summary>
        public static ServicioUpdateDto FromEntity(Servicio servicio)
        {
            return new ServicioUpdateDto
            {
                Id = servicio.Id,
                Nombre = servicio.Nombre,
                Descripcion = servicio.Descripcion,
                Precio = servicio.Precio.Valor,
                MonedaCodigo = servicio.Precio.Moneda,
                DuracionMinutos = servicio.DuracionMinutos,
                TipoServicioId = servicio.TipoServicioId, // ✅ CORREGIDO: ahora es int
                EsActivo = servicio.EsActivo
            };
        }
    }

    /// <summary>
    /// DTO simplificado para listas y selecciones
    /// </summary>
    public class ServicioListDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string PrecioFormateado { get; set; } = string.Empty;
        public string DuracionFormateada { get; set; } = string.Empty;
        public string TipoServicioNombre { get; set; } = string.Empty;
        public bool EsActivo { get; set; }
        public string EstadoCssClass { get; set; } = string.Empty;

        /// <summary>
        /// Convierte una entidad Servicio a DTO simplificado
        /// </summary>
        public static ServicioListDto FromEntity(Servicio servicio)
        {
            return new ServicioListDto
            {
                Id = servicio.Id,
                Nombre = servicio.Nombre,
                PrecioFormateado = $"${servicio.Precio.Valor:N2} {servicio.Precio.Moneda}",
                DuracionFormateada = FormatearDuracion(servicio.DuracionMinutos),
                TipoServicioNombre = servicio.TipoServicio?.Nombre ?? "Sin categoría",
                EsActivo = servicio.EsActivo,
                EstadoCssClass = servicio.EsActivo ? "badge-success" : "badge-danger"
            };
        }

        private static string FormatearDuracion(int duracionMinutos)
        {
            if (duracionMinutos < 60)
                return $"{duracionMinutos} min";
            else if (duracionMinutos == 60)
                return "1 hora";
            else if (duracionMinutos % 60 == 0)
                return $"{duracionMinutos / 60} horas";
            else
            {
                int horas = duracionMinutos / 60;
                int minutos = duracionMinutos % 60;
                return $"{horas}h {minutos}min";
            }
        }
    }

    /// <summary>
    /// DTO para filtros de búsqueda
    /// </summary>
    public class ServicioFiltroDto
    {
        [Display(Name = "Nombre")]
        public string? Nombre { get; set; }

        [Display(Name = "Tipo de Servicio")]
        public int? TipoServicioId { get; set; } // ✅ CORREGIDO: Guid? → int?

        [Display(Name = "Precio Mínimo")]
        [DataType(DataType.Currency)]
        public decimal? PrecioMin { get; set; }

        [Display(Name = "Precio Máximo")]
        [DataType(DataType.Currency)]
        public decimal? PrecioMax { get; set; }

        [Display(Name = "Solo Activos")]
        public bool SoloActivos { get; set; } = true;

        /// <summary>
        /// Indica si hay algún filtro aplicado
        /// </summary>
        public bool TieneFiltros => !string.IsNullOrWhiteSpace(Nombre) ||
                                    TipoServicioId.HasValue ||
                                    PrecioMin.HasValue ||
                                    PrecioMax.HasValue;
    }
}