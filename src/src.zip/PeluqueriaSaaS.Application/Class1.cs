﻿namespace PeluqueriaSaaS.Application;

public class Class1
{

}
