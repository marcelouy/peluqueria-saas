﻿namespace PeluqueriaSaaS.Domain;

public class Class1
{

}
