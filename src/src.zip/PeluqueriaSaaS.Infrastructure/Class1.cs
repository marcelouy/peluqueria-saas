﻿namespace PeluqueriaSaaS.Infrastructure;

public class Class1
{

}
